package com.example.ProjetoBack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
